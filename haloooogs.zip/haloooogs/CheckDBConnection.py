
import time
from DBContext import DbContext

def main():
    context = DbContext()

    while (True):
        ret = context.check_mongo_connection()
        if(ret):
            break
        
        time.sleep(10)
        

if __name__ == "__main__":
    main()
