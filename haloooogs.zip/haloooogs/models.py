from typing import *
from enum import Enum
from haproxyadmin import haproxy, utils
from haproxyadmin.internal.backend import _Backend
from haproxyadmin.internal.frontend import _Frontend
from haproxyadmin.internal.server import _Server


class NODE_TYPE(Enum):
    haproxy = 'haproxy'
    haproxyProcess = 'haproxyProcess'
    frontend = 'frontend'
    backend = 'backend'
    server = 'server'
    NONE = ''

class log_record(object):
    iid: int = 0
    nodeType: NODE_TYPE = NODE_TYPE.NONE.value

class ha_log_record(log_record):
    processids: List[int]
    nodename: str
    maxconn: int
    error: List
    acls: List
    info: List
    releasedate: str
    requests: int
    totalrequests: int
    uptime: str
    uptimesec: int
    version: str

    def __init__(self,id, ha: haproxy.HAProxy) -> None:
        super().__init__()
        self.nodeType = NODE_TYPE.haproxy.value
        self.processids = ha.processids
        self.nodename = ha.nodename
        self.maxconn = ha.maxconn
        self.error = ha.errors()
        self.acls = ha.show_acl()
        self.info = ha.info()
        self.releasedate = ha.releasedate
        self.requests = ha.requests
        self.totalrequests = ha.totalrequests
        self.uptime = ha.uptime
        self.uptimesec = ha.uptimesec
        self.version = ha.version


class hap_log_record(log_record):
    backends_stats: dict
    frontends_stats:dict
    proc_info: dict
    stats: dict


    def __init__(self, id, ha: haproxy._HAProxyProcess) -> None:
        super().__init__()
        self.nodeType = NODE_TYPE.haproxyProcess.value
        self.backends_stats = ha.backends_stats()
        self.frontends_stats = ha.frontends_stats()
        self.proc_info = ha.proc_info()
        self.stats = ha.stats()
    
class frontend_log_record(log_record):
    name: str
    stats: dict
    status: str

    def __init__(self,id, frontend: _Frontend) -> None:
        super().__init__()
        self.iid = frontend.iid
        self.nodeType = NODE_TYPE.frontend.value
        self.name = frontend.name
        
        stats = frontend.stats()
        self.status = stats['status']
        self.stats = stats


class backend_log_record(log_record):
    name: str
    stats: dict
    stickTable: List
    status: str
    balance: str

    def __init__(self,id, backend: _Backend, hap: haproxy._HAProxyProcess) -> None:
        super().__init__()
        self.iid = backend.iid
        self.nodeType = NODE_TYPE.backend.value
        
        stats = backend.stats()
        
        self.name = backend.name
        self.status = stats['status']
        self.balance = stats['algo']

        
        self.stickTable = hap.command(f'show table {self.name}', full_output=True)
        self.stats = stats
        

class server_log_record(log_record):
    name: str
    stats: dict
    backend: str
    status: str
    address: str
    
    def __init__(self,id, server: _Server) -> None:
        super().__init__()
        self.iid = server.sid
        self.nodeType = NODE_TYPE.server.value
        stats = server.stats()
        
        self.backend = stats['pxname']
        self.name = server.name
        self.status = stats['status']
        self.address = stats['addr']
        
        self.stats = stats
        
        
