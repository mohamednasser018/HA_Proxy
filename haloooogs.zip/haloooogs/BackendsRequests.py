from datetime import datetime
import  time
from DBContext import DbContext
from BackendListener import BackendListener
import cfg
import threading
from haproxy_Runtime import HA_Runtime
from typing import *
from models import NODE_TYPE


def main():
    context = DbContext()

    listener = BackendListener(cfg.GLOBAL[0], cfg.GLOBAL[1], context)

    listener.print_global_logs(["orchbackend", "orchestrator", "monitor"])
        

    print("finished")

if __name__ == "__main__":
    main()
